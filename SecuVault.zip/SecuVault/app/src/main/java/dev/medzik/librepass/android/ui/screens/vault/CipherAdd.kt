package dev.medzik.librepass.android.ui.screens.vault

import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun CipherAddScreen(navController: NavController) {
    CipherAddEditView(navController)
}
